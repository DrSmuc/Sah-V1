ispis pravila
upis igraca
ispis ploce




BP1-8 - BIJELI PJESACI
BT1-2 - BIJELI TOP 

BQ - BIJELA KRALJICA
BK - BIJELI KRALJ


  OZNAKO: B - BIJELA FIGURA
  