//provjera saha za bijelog

      for (int i=0;i<8;i++)
      {
          for (int j=0;j<8;j++)
          {
              if (ploca[i][j]==10)
              {
                pozicija_bk_i=i;
                pozicija_bk_j=j;
              }
          }
      }

                for (int i=pozicija_bk_i+1, j=pozicija_bk_j+1;i<8&&j<8;i++, j++)
                {
                    if (ploca[i][j]!=13&&(ploca[i][j]==9||ploca[i][j]==7))
                    {
                        bsah_dd=1;
                        break;
                    }
                    else
                        bsah_dd=0;
                }

                for (int i=pozicija_bk_i+1, j=pozicija_bk_j-1;i<8&&j>-1;i++, j--)
                {
                    if (ploca[i][j]!=13&&(ploca[i][j]==9||ploca[i][j]==7))
                    {
                        bsah_dl=1;
                        break;
                    }
                    else
                        bsah_dl=0;
                }


                for (int i=pozicija_bk_i-2, j=pozicija_bk_j+2;i>-1&&j<8;i--, j++)
                {
                    if (ploca[i][j]!=13&&(ploca[i][j]==9||ploca[i][j]==7))
                    {
                        bsah_gd=1;
                        break;
                    }
                    else
                        bsah_gd=0;
                }

                for (int i=pozicija_bk_i-2, j=pozicija_bk_j-2;i>-1&&j>-1;i--, j--)
                {
                    if (ploca[i][j]!=13&&(ploca[i][j]==9||ploca[i][j]==7))
                    {
                        bsah_gl=1;
                        break;
                    }
                    else
                        bsah_gl=0;
                }

                for (int i=pozicija_bk_i+1;i<8;i++)
                {
                    if (ploca[i][pozicija_bk_j]!=13&&(ploca[i][pozicija_bk_j]==3||ploca[i][pozicija_bk_j]==9))
                    {
                        bsah_d=1;
                        break;
                    }
                    else
                        bsah_d=0;
                }

                for (int i=pozicija_bk_i-1;i>-1;i--)
                {
                    if (ploca[i][pozicija_bk_j]!=13&&(ploca[i][pozicija_bk_j]==3||ploca[i][pozicija_bk_j]==9))
                    {
                        bsah_g=1;
                        break;
                    }
                    else
                        bsah_g=0;
                }

                for (int j=pozicija_bk_j+1;j<8;j++)
                {
                    if (ploca[pozicija_bk_i][j]!=13&&(ploca[pozicija_bk_i][j]==3||ploca[pozicija_bk_i][j]==9))
                    {
                        bsah_desno=1;
                        break;
                    }
                    else
                        bsah_desno=0;
                }

                for (int j=pozicija_bk_j-1;j>-1;j--)
                {
                    if (ploca[pozicija_bk_i][j]!=13&&(ploca[pozicija_bk_i][j]==3||ploca[pozicija_bk_i][j]==9))
                    {
                        bsah_l=1;
                        break;
                    }
                    else
                        bsah_l=0;
                }

                while (1)
                {
                    if (ploca[pozicija_bk_i+2][pozicija_bk_j+1]==4&&pozicija_bk_i+2>=0&&pozicija_bk_i+2<8&&pozicija_bk_j+1>=0&&pozicija_bk_j+1<8)
                        bsah_konj=1;
                    if (ploca[pozicija_bk_i+2][pozicija_bk_j-1]==4&&pozicija_bk_i+2>=0&&pozicija_bk_i+2<8&&pozicija_bk_j-1>=0&&pozicija_bk_j-1<8)
                        bsah_konj=1;
                    if (ploca[pozicija_bk_i+1][pozicija_bk_j+2]==4&&pozicija_bk_i+1>=0&&pozicija_bk_i+1<8&&pozicija_bk_j+2>=0&&pozicija_bk_j+1<8)
                        bsah_konj=1;
                    if (ploca[pozicija_bk_i+1][pozicija_bk_j-2]==4&&pozicija_bk_i+1>=0&&pozicija_bk_i+1<8&&pozicija_bk_j-2>=0&&pozicija_bk_j+1<8))
                        bsah_konj=1;
                    if (ploca[pozicija_bk_i-2][pozicija_bk_j+1]==4&&pozicija_bk_i-2>=0&&pozicija_bk_i-1<8&&pozicija_bk_j+1>=0&&pozicija_bk_j+1<8))
                        bsah_konj=1;
                    if (ploca[pozicija_bk_i-2][pozicija_bk_j-1]==4&&pozicija_bk_i-2>=0&&pozicija_bk_i-1<8&&pozicija_bk_j-1>=0&&pozicija_bk_j+1<8))
                        bsah_konj=1;
                    if (ploca[pozicija_bk_i-1][pozicija_bk_j+2]==4&&pozicija_bk_i-1>=0&&pozicija_bk_i-2<8&&pozicija_bk_j+2>=0&&pozicija_bk_j+1<8))
                        bsah_konj=1;
                    if (ploca[pozicija_bk_i-1][pozicija_bk_j-2]==4&&pozicija_bk_i-1>=0&&pozicija_bk_i-2<8&&pozicija_bk_j-2>=0&&pozicija_bk_j+1<8))
                        bsah_konj=1;
                    break;
                }

                if (ploca[pozicija_bk_i-1][pozicija_bk_j-1]==1||ploca[pozicija_bk_i-1][pozicija_bk_j+1]==1||ploca[pozicija_bk_i-1][pozicija_bk_j-1]==9||ploca[pozicija_bk_i+1][pozicija_bk_j-1]==9)
                    bsah_pijun=1;

                if (bsah_dd==1||bsah_dl==1||bsah_gl==1||bsah_gd==1||bsah_g==1||bsah_desno==1||bsah_d==1||bsah_l==1||bsah_konj==1||bsah_pijun==1)
                    printf("\nSAH NA BIJELOG!!!\n");


                for (int i=0;i<8;i++)
      {
          for (int j=0;j<8;j++)
          {
              if (ploca[i][j]==11)
              {
                pozicija_ck_i=i;
                pozicija_ck_j=j;
              }
          }
      }


                    for (int i=pozicija_ck_i+1, j=pozicija_ck_j+1;i<8&&j<8;i++, j++)
                {
                    if (ploca[i][j]!=13&&(ploca[i][j]==8||ploca[i][j]==6))
                    {
                        csah_dd=1;
                        break;
                    }
                    else
                        csah_dd=0;
                }

                for (int i=pozicija_ck_i+1, j=pozicija_ck_j-1;i<8&&j>-1;i++, j--)
                {
                    if (ploca[i][j]!=13&&(ploca[i][j]==8||ploca[i][j]==6))
                    {
                        csah_dl=1;
                        break;
                    }
                    else
                        csah_dl=0;
                }


                for (int i=pozicija_ck_i-2, j=pozicija_ck_j+2;i>-1&&j<8;i--, j++)
                {
                    if (ploca[i][j]!=13&&(ploca[i][j]==8||ploca[i][j]==6))
                    {
                        csah_gd=1;
                        break;
                    }
                    else
                        csah_gd=0;
                }

                for (int i=pozicija_ck_i-2, j=pozicija_ck_j-2;i>-1&&j>-1;i--, j--)
                {
                    if (ploca[i][j]!=13&&(ploca[i][j]==8||ploca[i][j]==6))
                    {
                        csah_gl=1;
                        break;
                    }
                    else
                        csah_gl=0;
                }

                for (int i=pozicija_ck_i+1;i<8;i++)
                {
                    if (ploca[i][pozicija_ck_j]!=13&&(ploca[i][pozicija_ck_j]==2||ploca[i][pozicija_ck_j]==8))
                    {
                        csah_d=1;
                        break;
                    }
                    else
                        csah_d=0;
                }

                for (int i=pozicija_ck_i-1;i>-1;i--)
                {
                    if (ploca[i][pozicija_ck_j]!=13&&(ploca[i][pozicija_ck_j]==2||ploca[i][pozicija_ck_j]==8))
                    {
                        csah_g=1;
                        break;
                    }
                    else
                        csah_g=0;
                }

                for (int j=pozicija_ck_j+1;j<8;j++)
                {
                    if (ploca[pozicija_ck_i][j]!=13&&(ploca[pozicija_ck_i][j]==2||ploca[pozicija_ck_i][j]==8))
                    {
                        csah_desno=1;
                        break;
                    }
                    else
                        csah_desno=0;
                }

                for (int j=pozicija_ck_j-1;j>-1;j--)
                {
                    if (ploca[pozicija_ck_i][j]!=13&&(ploca[pozicija_ck_i][j]==2||ploca[pozicija_ck_i][j]==8))
                    {
                        csah_l=1;
                        break;
                    }
                    else
                        csah_l=0;
                }

                while (1)
                {
                    if (ploca[pozicija_ck_i+2][pozicija_ck_j+1]==4&&pozicija_ck_i+2>=0&&pozicija_ck_i+2<8&&pozicija_ck_j+1>=0&&pozicija_ck_j+1<8)
                        csah_konj=1;
                    if (ploca[pozicija_ck_i+2][pozicija_ck_j-1]==4&&pozicija_ck_i+2>=0&&pozicija_ck_i+2<8&&pozicija_ck_j-1>=0&&pozicija_ck_j-1<8)
                        csah_konj=1;
                    if (ploca[pozicija_ck_i+1][pozicija_ck_j+2]==4&&pozicija_ck_i+1>=0&&pozicija_ck_i+1<8&&pozicija_ck_j+2>=0&&pozicija_ck_j+1<8)
                        csah_konj=1;
                    if (ploca[pozicija_ck_i+1][pozicija_ck_j-2]==4&&pozicija_ck_i+1>=0&&pozicija_ck_i+1<8&&pozicija_ck_j-2>=0&&pozicija_ck_j+1<8))
                        csah_konj=1;
                    if (ploca[pozicija_ck_i-2][pozicija_ck_j+1]==4&&pozicija_ck_i-2>=0&&pozicija_ck_i-1<8&&pozicija_ck_j+1>=0&&pozicija_ck_j+1<8))
                        csah_konj=1;
                    if (ploca[pozicija_ck_i-2][pozicija_ck_j-1]==4&&pozicija_ck_i-2>=0&&pozicija_ck_i-1<8&&pozicija_ck_j-1>=0&&pozicija_ck_j+1<8))
                        csah_konj=1;
                    if (ploca[pozicija_ck_i-1][pozicija_ck_j+2]==4&&pozicija_ck_i-1>=0&&pozicija_ck_i-2<8&&pozicija_ck_j+2>=0&&pozicija_ck_j+1<8))
                        csah_konj=1;
                    if (ploca[pozicija_ck_i-1][pozicija_ck_j-2]==4&&pozicija_ck_i-1>=0&&pozicija_ck_i-2<8&&pozicija_ck_j-2>=0&&pozicija_ck_j+1<8))
                        csah_konj=1;
                    break;
                }

                if (ploca[pozicija_ck_i+1][pozicija_ck_j-1]==0||ploca[pozicija_ck_i+1][pozicija_ck_j+1]==0||ploca[pozicija_bk_i+1][pozicija_bk_j-1]==8||ploca[pozicija_bk_i+1][pozicija_bk_j+1]==8)
                    csah_pijun=1;

                if (csah_dd==1||csah_dl==1||csah_gl==1||csah_gd==1||csah_g==1||csah_desno==1||csah_d==1||csah_l==1||csah_konj==1||csah_pijun==1)
                    printf("\nSAH NA CRNOG!!!\n");

//kada je sah sa kraljicom pored kralja da mora uzet - CQ
//pogledat kretanje bijele kraljice